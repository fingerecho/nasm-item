#include "inotifyservice1.h"

InotifyService1::InotifyService1()
{
    // open the target file
    targetFile = fopen("action.txt","w+");
    if(targetFile==NULL)
    {
        fprintf(stderr,"ERROR:%s\n","open file failed!");
        return ;
    }
}

InotifyService1::~InotifyService1()
{
    if(targetFile!=NULL)
        fclose(targetFile);
}
void InotifyService1::reopen(std::string path)
{
    flag=false;
    std::string npth;
    if(targetFile!=NULL)
        fclose(targetFile);
    npth = path + "/" + "actionInfomation.txt";
    targetFile = fopen(npth.c_str(),"w+");
    if(targetFile==NULL)
    {
        //throw exception
        fprintf(stderr,"ERROR in reopen:%s\n","re open file failed!");
        return ;
    }
    msleep(1000);
    flag=true;
}
void InotifyService1::run()
{
    // initialize and watch the entire directory tree from the current
        // working directory downwards for all events
    if (!inotifytools_initialize() ||
        !inotifytools_watch_recursively("/",
           // IN_ALL_EVENTS
           //IN_ACCESS | IN_MODIFY | IN_ATTRIB | IN_CLOSE_WRITE | \
           //IN_CLOSE_NOWRITE | IN_OPEN | IN_MOVED_FROM | \
           //IN_MOVED_TO | IN_DELETE | IN_CREATE | IN_DELETE_SELF | \
           //IN_MOVE_SELF
           IN_ACCESS | IN_OPEN | IN_CREATE
            )) {
        fprintf(targetFile, "%s\n", strerror(inotifytools_error()));
        return ;
    }

    // set time format to 24 hour time, HH:MM:SS
    inotifytools_set_printf_timefmt("%T");

    while(flag)
    {
        do
        {
            qDebug()<<"InotifyService1::run!!!"<<endl;

            event = inotifytools_next_event(-1);
            inotifytools_fprintf(targetFile, event, "%T: %w %f %e\n");
            fflush(targetFile);
        }while (event);
    }
}
