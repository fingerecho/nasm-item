#ifndef DIALOG_H
#define DIALOG_H

#include <QSystemTrayIcon>

#include <QMessageBox>

#include <QDialog>

#include <QLineEdit>

#include <QFileInfo>

#include "inotifyservice1.h"

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    void trayActivated(QSystemTrayIcon::ActivationReason reason);
    explicit Dialog(InotifyService1* svc,QWidget *parent = 0);
    ~Dialog();

private slots:
    void on_actBtn_clicked();

    void on_dvcBtn_clicked();

private:
    Ui::Dialog *ui;
    InotifyService1* m_svc;
};

#endif // DIALOG_H
