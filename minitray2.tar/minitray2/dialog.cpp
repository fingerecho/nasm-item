#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(InotifyService1* svc,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    m_svc = svc;
    QSystemTrayIcon *trayIcon = new QSystemTrayIcon(this);
    connect(trayIcon,&QSystemTrayIcon::activated,this,&Dialog::trayActivated);
    trayIcon->setIcon(QIcon(":/images/heart.png"));
    trayIcon->show();

    ui->setupUi(this);

}

Dialog::~Dialog()
{
    delete ui;
}
void Dialog::trayActivated(QSystemTrayIcon::ActivationReason reason)
{
    switch(reason)
    {
        case QSystemTrayIcon::Trigger:
                        {
                            this->show();

                            break;
                        }
        case QSystemTrayIcon::DoubleClick:
                    {
                        this->show();

                        break;
                    }
        case QSystemTrayIcon::MiddleClick:
                    {
                        this->show();

                        break;
                    }
    }
}
void Dialog::on_actBtn_clicked()
{
    QString actQS;
    QByteArray actQBtary;
    std::string actPth;
    QFileInfo actQFinfo ;
    actQS = ui->actLineedit->text();

    actQFinfo = QFileInfo(actQS);
    if(actQFinfo.isDir())
    {
        actQBtary = actQS.toLocal8Bit();
        actPth = std::string(actQBtary);
        this->m_svc->reopen(actPth);
        QMessageBox::critical(0, QObject::tr("Hints"),QObject::tr("路径更改成功!"));
    }else{
        QMessageBox::critical(0, QObject::tr("Hints"),QObject::tr("路径不存在或者是无效目录!"));
    }
}

void Dialog::on_dvcBtn_clicked()
{
    QString dvcQS;
    QByteArray dvcQBtary;
    std::string dvcPth,cmd;
    QFileInfo dvcQFinfo;
    dvcQS = ui->dvcLineedit->text();
    dvcQFinfo = QFileInfo(dvcQS);
    if(dvcQFinfo.isDir())
    {
        dvcQBtary = dvcQS.toLocal8Bit();
        dvcPth = std::string(dvcQBtary);
        cmd = " lshw > " + dvcPth + "/deviceInfomation.txt";
        system(cmd.c_str());
        QMessageBox::critical(0, QObject::tr("Hints"),QObject::tr("路径更改成功!"));
    }else{
        QMessageBox::critical(0, QObject::tr("Hints"),QObject::tr("路径不存在或者是无效目录!"));
    }
}
