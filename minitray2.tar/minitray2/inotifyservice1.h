#ifndef INOTIFYSERVICE1_H
#define INOTIFYSERVICE1_H

#include "inotifytools/inotifytools/inotify.h"
#include "inotifytools/inotifytools/inotifytools.h"

#include <QThread>
#include <QDebug>

class InotifyService1 : public QThread
{
    Q_OBJECT
public:
    InotifyService1();
    ~InotifyService1();
    void reopen(std::string);

protected:
    void run() Q_DECL_OVERRIDE;
private:
    FILE* targetFile;
    struct inotify_event* event;
    bool flag=true;
};

#endif // INOTIFYSERVICE1_H
