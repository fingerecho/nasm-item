#include "dialog.h"
#include <QApplication>

#include <QMessageBox>

/*
 *
    QApplication app(argc, argv);

    if (!QSystemTrayIcon::isSystemTrayAvailable()) {
        QMessageBox::critical(0, QObject::tr("Systray"),
                              QObject::tr("I couldn't detect any system tray "
                                          "on this system."));
        return 1;
    }
    QApplication::setQuitOnLastWindowClosed(false);

    TestService2 *service2 = new TestService2();
    service2->start();
    InotifyService1 *service1 = new InotifyService1();
    service1->start();

    Window window(NULL,service2);
    window.show();
    app.exec();

 **/
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    if (!QSystemTrayIcon::isSystemTrayAvailable()) {
        QMessageBox::critical(0, QObject::tr("tray"),
                              QObject::tr("I couldn't detect any system tray "
                                          "on this system."));
        return 1;
    }

    //do not quit tray when click quit in dialog
    QApplication::setQuitOnLastWindowClosed(false);
    InotifyService1 *service1 = new InotifyService1();
    service1->start();

    Dialog w(service1);
    w.hide();

    return a.exec();
}
